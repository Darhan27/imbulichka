from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_socketio import join_room, leave_room, send, SocketIO
app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mydatabase.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

socketio = SocketIO(app)


@app.route('/')
def index():
    return render_template("index.html")


@app.route('/about')
def about():
    return "wefdf"
@socketio.on("connect")
def obr(data):
    join_room(1)
@socketio.on("message")
def obr(data):
    send(data,to=1)
if __name__ == "__main__":
    app.run(debug=True)