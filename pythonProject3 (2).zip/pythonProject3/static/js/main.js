const socketio = io('http://127.0.0.1:5000/')
function sehen(){
    var elem=document.getElementById('massenger')
    if(document.getElementById('baatyly1').value=="" ) {
        return;
    }
    socketio.emit("message", document.getElementById('baatyly1').value)
    document.getElementById('baatyly1').value="";
}

socketio.on("message",(a)=>{
    document.getElementById('massenger').innerHTML+="<div>"+a+"</div>";
});